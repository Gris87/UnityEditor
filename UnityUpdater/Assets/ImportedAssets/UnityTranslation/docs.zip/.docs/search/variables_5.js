var searchData=
[
  ['pluralsfunctions',['pluralsFunctions',['../class_unity_translation_internal_1_1_plurals_rules.html#a5d6f211cdb84762ff1e3b125f743ceb9',1,'UnityTranslationInternal::PluralsRules']]],
  ['pluralsvalues',['pluralsValues',['../class_unity_translation_internal_1_1_translator_1_1_section_locale_tokens.html#a3f1bed3be28c56b070ee39fbd1577cb6',1,'UnityTranslationInternal::Translator::SectionLocaleTokens']]]
];
