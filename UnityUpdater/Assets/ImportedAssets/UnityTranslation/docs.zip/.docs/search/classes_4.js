var searchData=
[
  ['sectionlocaletokens',['SectionLocaleTokens',['../class_unity_translation_internal_1_1_translator_1_1_section_locale_tokens.html',1,'UnityTranslationInternal::Translator']]],
  ['sections',['sections',['../class_unity_translation_1_1_r_1_1sections.html',1,'UnityTranslation::R']]],
  ['sectiontokens',['SectionTokens',['../class_unity_translation_internal_1_1_translator_1_1_section_tokens.html',1,'UnityTranslationInternal::Translator']]]
];
