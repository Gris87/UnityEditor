var searchData=
[
  ['xmlfiles',['xmlFiles',['../class_unity_translation_1_1_r_1_1sections.html#a58216be7048ef134a428099db1e40c43',1,'UnityTranslation::R::sections']]]
];
