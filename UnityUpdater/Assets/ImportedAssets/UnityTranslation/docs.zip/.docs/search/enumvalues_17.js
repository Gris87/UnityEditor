var searchData=
[
  ['xhosa',['Xhosa',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a66ab19a0e3494a5be5598b106d98d651',1,'UnityTranslation']]],
  ['xiangchinese',['XiangChinese',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a4cb9c8b7414a1dac3ca43c64556f7a42',1,'UnityTranslation']]]
];
