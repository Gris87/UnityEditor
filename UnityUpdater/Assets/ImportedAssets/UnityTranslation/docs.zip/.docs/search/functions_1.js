var searchData=
[
  ['checktokenname',['checkTokenName',['../class_unity_translation_internal_1_1_utils.html#aff771a46cbee2bbd959a45cd48b1fc3c',1,'UnityTranslationInternal::Utils']]],
  ['codetolanguage',['codeToLanguage',['../class_unity_translation_1_1_language_code.html#a06546b24d64cd2ebed676a7797a737fd',1,'UnityTranslation::LanguageCode']]]
];
