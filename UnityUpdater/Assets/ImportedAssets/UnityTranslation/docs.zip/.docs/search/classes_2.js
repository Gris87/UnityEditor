var searchData=
[
  ['pluralsrules',['PluralsRules',['../class_unity_translation_internal_1_1_plurals_rules.html',1,'UnityTranslationInternal']]]
];
