var searchData=
[
  ['vai',['Vai',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273adaf357a25d1a1ecd206f3e3dc505f4c2',1,'UnityTranslation']]],
  ['venda',['Venda',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a78df616ab31e95ee46c6a519a2ce9e12',1,'UnityTranslation']]],
  ['venetian',['Venetian',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273af3bf6d00520987e514d95168feb60a0b',1,'UnityTranslation']]],
  ['veps',['Veps',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273af021986739c0d675569c37b206ff2f06',1,'UnityTranslation']]],
  ['vietnamese',['Vietnamese',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a7b80fae85640c16cdb0261bef0c27636',1,'UnityTranslation']]],
  ['volapuk',['Volapuk',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273aa28c6f221dfa1225107773b13f2c3e2f',1,'UnityTranslation']]],
  ['voro',['Voro',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a828b7ee8bd656973f1a3288b2c3d6e9e',1,'UnityTranslation']]],
  ['votic',['Votic',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273afa174b8229dc4d5725fc2979dc65cde9',1,'UnityTranslation']]],
  ['vunjo',['Vunjo',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a403508ed4b41e3434333b0238ee4acd0',1,'UnityTranslation']]]
];
