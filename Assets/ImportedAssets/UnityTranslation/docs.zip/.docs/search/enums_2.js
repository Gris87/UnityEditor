var searchData=
[
  ['plurals',['plurals',['../class_unity_translation_1_1_r.html#af06dd275fc4b70eb2d61e451f9a7b493',1,'UnityTranslation::R']]],
  ['pluralsquantity',['PluralsQuantity',['../namespace_unity_translation_internal.html#a6d4919d41b76525f811bc6e69862d8b1',1,'UnityTranslationInternal']]]
];
