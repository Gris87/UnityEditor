var searchData=
[
  ['language',['language',['../class_unity_translation_1_1_translator.html#a48b9f208ab9b58ae4d4f68b865dbff3a',1,'UnityTranslation.Translator.language()'],['../class_unity_translation_internal_1_1_translator.html#a6ab474ae34b4b3aaa90eb633fcfd7f11',1,'UnityTranslationInternal.Translator.language()']]]
];
