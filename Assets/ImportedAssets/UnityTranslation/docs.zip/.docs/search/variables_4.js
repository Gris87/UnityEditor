var searchData=
[
  ['names',['names',['../class_unity_translation_1_1_language_name.html#a330dd483c7a2c428a1eca1b1dea5cbc0',1,'UnityTranslation::LanguageName']]]
];
