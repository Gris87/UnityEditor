var searchData=
[
  ['onlanguagechanged',['OnLanguageChanged',['../class_unity_translation_1_1_text_auto_translation.html#ace0ca2792f9ee759192164b1fde17528',1,'UnityTranslation::TextAutoTranslation']]]
];
