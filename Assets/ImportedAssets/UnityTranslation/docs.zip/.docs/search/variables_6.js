var searchData=
[
  ['selectedlanguage',['selectedLanguage',['../class_unity_translation_internal_1_1_translator_1_1_section_tokens.html#a946b7d8d2fe2e202c549c4b31ae3a30b',1,'UnityTranslationInternal::Translator::SectionTokens']]],
  ['stringarrayvalues',['stringArrayValues',['../class_unity_translation_internal_1_1_translator_1_1_section_locale_tokens.html#a1408f41e827d0c1b04f214334011788c',1,'UnityTranslationInternal::Translator::SectionLocaleTokens']]],
  ['stringvalues',['stringValues',['../class_unity_translation_internal_1_1_translator_1_1_section_locale_tokens.html#a4a9a984ed01b383a8d52314462cf1b51',1,'UnityTranslationInternal::Translator::SectionLocaleTokens']]],
  ['systemlanguages',['systemLanguages',['../class_unity_translation_1_1_language_system_name.html#ae3ca4a0b1586e2881fc63f11d4f7d965',1,'UnityTranslation::LanguageSystemName']]]
];
