var searchData=
[
  ['r',['R',['../class_unity_translation_1_1_r.html',1,'UnityTranslation']]]
];
