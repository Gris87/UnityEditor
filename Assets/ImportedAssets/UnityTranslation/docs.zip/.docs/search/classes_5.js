var searchData=
[
  ['textautotranslation',['TextAutoTranslation',['../class_unity_translation_1_1_text_auto_translation.html',1,'UnityTranslation']]],
  ['translator',['Translator',['../class_unity_translation_internal_1_1_translator.html',1,'UnityTranslationInternal']]],
  ['translator',['Translator',['../class_unity_translation_1_1_translator.html',1,'UnityTranslation']]]
];
