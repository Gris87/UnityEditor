var searchData=
[
  ['tokenids',['tokenIds',['../class_unity_translation_1_1_r.html#a7c10ae922c4783d4ce7e9a306b4dcddd',1,'UnityTranslation::R']]],
  ['tokens',['tokens',['../class_unity_translation_internal_1_1_translator.html#abae53f9b9d5001cabcfb7c3541471122',1,'UnityTranslationInternal::Translator']]]
];
