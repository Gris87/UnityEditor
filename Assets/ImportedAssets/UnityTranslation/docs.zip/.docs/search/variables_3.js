var searchData=
[
  ['languages',['languages',['../class_unity_translation_1_1_language_system_name.html#a7f7db3cb01e2a6378a2f42431c9eba6e',1,'UnityTranslation::LanguageSystemName']]],
  ['list',['list',['../class_unity_translation_1_1_available_languages.html#ad773f39a1f62c2af72650607783ed61d',1,'UnityTranslation::AvailableLanguages']]]
];
