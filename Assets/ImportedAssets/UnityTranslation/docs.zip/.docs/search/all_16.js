var searchData=
[
  ['walloon',['Walloon',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273adee445b5f2566bcb8ee3ee19e4d8f1bc',1,'UnityTranslation']]],
  ['walser',['Walser',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a127fea8a1623861b7862b37ea52fb540',1,'UnityTranslation']]],
  ['waray',['Waray',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a53c30045ab8392a2843d4cede29d1601',1,'UnityTranslation']]],
  ['washo',['Washo',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273accd9179b42c5b6e6ea3ea1c3d0a1d1a9',1,'UnityTranslation']]],
  ['wayuu',['Wayuu',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a1b8e87693a3e28cf2935f7ca766226d4',1,'UnityTranslation']]],
  ['welsh',['Welsh',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273abbb0fa49b525c4264f4ad7a06adc3e07',1,'UnityTranslation']]],
  ['westernfrisian',['WesternFrisian',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273aad19bb17f84d68021805c2287995a294',1,'UnityTranslation']]],
  ['westernmari',['WesternMari',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a2975916b60dc185ab801d48aa5fe5eba',1,'UnityTranslation']]],
  ['westflemish',['WestFlemish',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273ade479a4f299cff6a223b22efac086800',1,'UnityTranslation']]],
  ['wolaytta',['Wolaytta',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a054302b942eef7ea2fffd415102d6d24',1,'UnityTranslation']]],
  ['wolof',['Wolof',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273a410d89e3c3647c6332d7412d2d46ef69',1,'UnityTranslation']]],
  ['wuchinese',['WuChinese',['../namespace_unity_translation.html#a58da4e04fd89ff820cedbb1c6b059273ab078a7fd044870bd5cbc4000070ae032',1,'UnityTranslation']]]
];
